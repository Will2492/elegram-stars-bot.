# Telegram Stars Bot

Бот для продажи Telegram Stars.

## Установка

1. Склонируйте репозиторий:

```bash
git clone https://github.com/yourusername/telegram-stars-bot.git
cd telegram-stars-bot
```

2. Установите зависимости:

```bash
pip install -r requirements.txt
```

3. Вставьте свой API токен от @BotFather в `bot.py`.

4. Запустите бота:

```bash
python bot.py
```

## Контакты

Поддержка: @yourusername